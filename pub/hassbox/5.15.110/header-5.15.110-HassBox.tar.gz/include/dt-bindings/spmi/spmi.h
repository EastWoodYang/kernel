/* SPDX-License-Identifier: GPL-2.0-only */
/* Copyright (c) 2013, The Linux Foundation. All rights reserved.
 */
#ifndef __DT_BINDINGS_SPMI_H
#define __DT_BINDINGS_SPMI_H

#define SPMI_USID	0
#define SPMI_GSID	1

#endif
