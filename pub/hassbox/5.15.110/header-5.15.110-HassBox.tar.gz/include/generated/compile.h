/* This file is auto generated, version 1 */
/* SMP PREEMPT */
#define UTS_MACHINE "aarch64"
#define UTS_VERSION "#1 SMP PREEMPT Sun May 7 05:22:36 EDT 2023"
#define LINUX_COMPILE_BY "root"
#define LINUX_COMPILE_HOST "fv-az573-657"
#define LINUX_COMPILER "Ubuntu clang version 14.0.0-1ubuntu1, Ubuntu LLD 14.0.0"
